
public class aPixel {
	public static void main(String[] args) {
		//Entorno:
		Pixel pix, pixBoom;
		IPunto ip = null;
		
		//Algoritmo:
		pix = new Pixel();
		pix.imprime();
		
//		ip.setX(12);
//		ip.setY(3);
//		pixBoom = new Pixel(ip, 2);
		
		pix.setX(12);
		pix.setY(3);
		pix.cambiarColor(1);
		pix.imprime();
		
		System.out.println(pix.getX() + ", " + pix.getY());
		pix.mover(3, 12);
		pix.imprime();
//		pix.mover(ip);
//		pix.imprime();
		
//		System.out.println(pix.distancia(ip));
		
		pix.imprime();
		pix.borrar();
		pix.imprime();
	}
}
