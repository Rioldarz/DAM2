
public class Punto implements IPunto {
	// Atributos:
	private double x, y;

	// Constructor:
	public Punto() {
		this.x = 0;
		this.y = 0;
	}// Fin Constructor

	public Punto(double n1, double n2) {
		this.x = n1;
		this.y = n2;
	}// Fin Constructor

	// Métodos:
	@Override
	public double getX() {
		return this.x;
	}// Fin Función

	@Override
	public double getY() {
		return this.y;
	}// Fin Función

	@Override
	public void setX(double x) {
		this.x = x;
	}// Fin Procedimiento

	@Override
	public void setY(double y) {
		this.y = y;
	}// Fin Procedimiento

	@Override
	public void mover(double n1, double n2) {
		this.x = n1;
		this.y = n1;
	}// Fin Procedimiento

	@Override
	public void mover(IPunto p) {
		this.x = p.getX();
		this.y = p.getY();
	}// Fin Procedimiento

	@Override
	public void borrar() {
		this.x = 0;
		this.y = 0;
	}// Fin Procedimiento

	public double distancia(IPunto ip) {
		return Math.pow((this.getX() - ip.getX()), 2) + Math.pow((this.getY() - ip.getY()), 2);
	}// Fin Función

	public void imprime() {
		System.out.println(this.x + ", " + this.y);
	}// Fin Procedimiento

}
