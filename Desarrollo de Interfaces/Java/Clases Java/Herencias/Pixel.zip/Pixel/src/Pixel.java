
public class Pixel extends Punto{
	//Atributos:
	private int color;
	
	//Constructor:
	public Pixel() {
		super();
		this.color = 0;
	}//Fin Constructor
	
	public Pixel(IPunto ip, int color) {
		//No sé para qué la referencia de IPunto
		this.color = color;
	}//Fin Constructor
	
	//Métodos:
	@Override
	public void imprime() {
		System.out.println(super.getX() + ", " + super.getY() + ", " + this.color);
	}// Fin Procedimiento
	
	@Override
	public void borrar() {
		super.setX(0);
		super.setY(0);
		this.color = 0;
	}// Fin Procedimiento
	
	public void cambiarColor(int color) {
		this.color = color;
	}//Fin Procedimiento
}
