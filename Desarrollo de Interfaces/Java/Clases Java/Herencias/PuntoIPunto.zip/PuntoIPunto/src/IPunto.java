
public interface IPunto {
	public void mover(double n1, double n2);

	public void mover(IPunto p);

	public void borrar();

	public double getX();

	public double getY();

	public void setX(double x);

	public void setY(double y);
}
