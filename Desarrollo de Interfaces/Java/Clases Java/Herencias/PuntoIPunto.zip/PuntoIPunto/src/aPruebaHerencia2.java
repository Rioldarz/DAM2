
public class aPruebaHerencia2 {
	public static void main(String[] args) {
		// Entorno:
		Punto pLimpio, pProfundo;
		IPunto ip = null;

		// Algoritmo:
		pLimpio = new Punto();
		pProfundo = new Punto(5, 10);

		pLimpio.imprime();
		pProfundo.imprime();

		pLimpio.setX(150);
		pLimpio.setY(20);

		System.out.println(pLimpio.getX() + " " + pLimpio.getY());
		System.out.println(pProfundo.getX() + " " + pProfundo.getY());

		// OJO EXPLOTO DESDE AQUÍ:
//		ip.setX(4);
//		ip.setY(11);
//		System.out.println(pLimpio.distancia(ip));
//		System.out.println(pProfundo.distancia(ip));

//		pLimpio.mover(ip);
		// HASTA AQUÍ
		pProfundo.mover(25, 48);

		pLimpio.imprime();
		pProfundo.imprime();

		pLimpio.borrar();
		pProfundo.borrar();

		pLimpio.imprime();
		pProfundo.imprime();
	}
}
