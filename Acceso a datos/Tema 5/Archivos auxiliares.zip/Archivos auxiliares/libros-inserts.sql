INSERT INTO `Libros` (`id`,`titulo`,`autor`,`fecha`,`precio`,`disponibilidad`,`destacado`,`imagen`,`descripcion`,`idCategoria`) 
VALUES (1,'Los girasoles ciegos.','Alberto Méndez.','2004-01-01',14.9,'Disponible',1,'girasoles.png','<p><strong>Ambientado:</strong><br />Guerra civil</p>',1);
