INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (1,'Literarios','Este tipo de libro son los más comunes e incluyen, por ejemplo, las novelas y los poemarios.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (2,'De texto','Son los libros que se utilizan en los centros de enseñanza.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (3,'Didacticos','Su público es principalmente infantil.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (4,'Cientificos','Todo lo expuesto en estos libros es exclusivamente de carácter científico (medicina, biología, astronomía…), y a menudo se trata de hipotésis o teorías basadas en lo expuesto por otros autores.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (5,'Tecnicos','Son libros que tratan un tema específico de una manera muy detallada, conteniendo un gran número de tecnicismos.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (6,'De consulta','Solo se utilizan para realizar consultas rápidas, como es el caso de un diccionario o una enciclopedia. Son muy útiles como apoyo.');
INSERT INTO `Categorias` (`id`,`nombre`,`descripcion`) VALUES (8,'Biografico','Los libros biográficos narran la vida de una persona a través de sus logros, fracasos y experiencias a lo largo de los años.');
